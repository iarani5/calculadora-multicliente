package calculadora_SSDD_TP3;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cliente {

    public static void main(String[] args) {

        //Host del servidor
        final String HOST = "127.0.0.1";
        //Puerto del servidor
        final int PUERTO = 6000;
        DataInputStream in;
        DataOutputStream out;

        try {
            //Creo el socket para conectarme con el cliente
            Socket sc = new Socket(HOST, PUERTO);
       
            in = new DataInputStream(sc.getInputStream());
            out = new DataOutputStream(sc.getOutputStream());

            

            String peticion = "s";                                       
            while (peticion.equals("s") || peticion.equals("S")){
            		Scanner entradaEscaner = new Scanner (System.in); //Creaci�n de un objeto Scanner
                	String operacion = ""; //creamos string vacio de operacion            
                    System.out.println( "\nEnvia una operacion al servidor: " );
                    operacion = entradaEscaner.nextLine (); //guardamos el dato que se ingrese en la variable operacion     
                	
                    //Envio la operacion al servidor                   
                    out.writeUTF(operacion);               	
                
                
                    //Recibo el mensaje del servidor
                    String resultado = in.readUTF();

                    System.out.println("\nEl resultado es: "+resultado);
               
                                              
              //Envio mensaje si deseo realizar otra operacion 
                Scanner entrada = new Scanner (System.in); //Creaci�n de un objeto Scanner
                System.out.println( "\nAprete 's' para realizar otra operacion o cualquier otra letra para finalizar: " );
                peticion = entrada.nextLine (); //guardamos el dato que se ingrese en la variable operacion   
                System.out.println(peticion);              
                out.writeUTF(peticion); 
               
            }
                 	
            	//Cierro el socket
                sc.close();

        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
