package calculadora_SSDD_TP3;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Servidor {
   
	 private static boolean compareSymbols(String newSymbol,String existSymbol){
	        
	        if(existSymbol.equals("(")) return true;
	        //misma prioridad
	        if(newSymbol.equals(existSymbol)) return false;
	        else if((newSymbol.equals("*")||newSymbol.equals("/")||newSymbol.equals("^"))&&(existSymbol.equals("*")||existSymbol.equals("/")||existSymbol.equals("^"))) return false;
	        else if((newSymbol.equals("+")||newSymbol.equals("-"))&&(existSymbol.equals("+")||existSymbol.equals("-"))) return false;
	        //diferente prioridad
	        else if((newSymbol.equals("-") ||newSymbol.equals("+")) &&(existSymbol.equals("*") || existSymbol.equals("/")|| existSymbol.equals("^"))) return false;
	        
	        return true;
	 }

	//Get de nueva expresion
    private static LinkedList<String> getNewExpre(String[] expression){
        LinkedList<String> symbols=new LinkedList<>();//Stack para simbolos
        LinkedList<String> newExpre=new LinkedList<>();//Stack para nueva expresion
        for (int i=0;i<expression.length;i++){
            String val=expression[i];
            if(val.equals("")) continue;
            switch (val){
                case "(":symbols.add(val);break;
                case ")":
                    boolean isOk=true;
                    while(isOk){
                        String _symbol=symbols.pollLast();
                        if(_symbol.equals("(")) isOk=false;
                        else newExpre.add(_symbol);
                    };
                    break;
                case "+":
                case "-":
                case "*":
                case "/":
                case "^":
                    if(symbols.size()==0){
                        symbols.add(val);
                    } else if(compareSymbols(val,symbols.get(symbols.size()-1))) symbols.add(val);
                    else{
                        while (symbols.size()>0 && !compareSymbols(val,symbols.get(symbols.size()-1))){
                            newExpre.add(symbols.pollLast());// hace un stack all hasta que la priodidad sea mas chica que la actual
                        }
                        symbols.add(val);
                    }
                    break;
                default:
                    newExpre.add(val);
            }
        }
        while(symbols.size()>0){
            newExpre.add(symbols.pollLast());
        }
        return newExpre;
    }

	  private static String cal(String str){
		  
	        //Get a new expression
	        LinkedList<String> expre=getNewExpre(str.split(" "));
	      
	        for(var i=0;i<expre.size();i++){
	            var val=expre.get(i);
	            switch(val){
	                case "-":
	                    expre.set(i-2,String.valueOf(Double.valueOf(expre.get(i-2).toString())-Double.valueOf(expre.get(i-1).toString())));
	                    expre.remove(i-1);
	                    expre.remove(i-1);
	                    i-=2;
	                    break;
	                case "+":
	                    expre.set(i-2,String.valueOf(Double.valueOf(expre.get(i-2).toString())+Double.valueOf(expre.get(i-1).toString())));
	                    expre.remove(i-1);
	                    expre.remove(i-1);
	                    i-=2;
	                    break;
	                case "*":
	                    expre.set(i-2,String.valueOf(Double.valueOf(expre.get(i-2).toString())*Double.valueOf(expre.get(i-1).toString())));
	                    expre.remove(i-1);
	                    expre.remove(i-1);
	                    i-=2;
	                    break;
	                case "^":
	                	double rta = Math.pow(Double.valueOf(expre.get(i-2).toString()),Double.valueOf(expre.get(i-1).toString()));
	                    expre.set(i-2,String.valueOf(rta));
	                    expre.remove(i-1);
	                    expre.remove(i-1);
	                    i-=2;
	                    break;
	                case "/":
	                    expre.set(i-2,String.valueOf(Double.valueOf(expre.get(i-2).toString())/Double.valueOf(expre.get(i-1).toString())));
	                    expre.remove(i-1);
	                    expre.remove(i-1);
	                    i-=2;
	                    break;
	                default:
	                    break;
	            }
	        }
	        return expre.get(0);
			
	    }
	  
	  
	public static void main(String[] args) {

        ServerSocket servidor = null;
        Socket sc = null;
        DataInputStream in;
        DataOutputStream out;

        //puerto de nuestro servidor
        final int PUERTO = 6000;

        try {
            //Creamos el socket del servidor
            servidor = new ServerSocket(PUERTO);
            System.out.println(">>>> Servidor Calculadora iniciado");

            //Siempre estara escuchando peticiones
            while (true) {

                //Espero a que un cliente se conecte
                sc = servidor.accept();

                System.out.println("\n>>>> Cliente conectado");
                in = new DataInputStream(sc.getInputStream());
                out = new DataOutputStream(sc.getOutputStream());


              String peticion = "s";                                       
              while (peticion.equals("s") || peticion.equals("S")){
            	  
            	  
                	System.out.print( "\n>>>> El cliente esta realizando una operacion ... " );
                	String operacion = in.readUTF();
                	
                	//calculo
                	String resultado = cal(operacion);
                	
                    //Le envio el resultado al cliente
                    out.writeUTF(resultado);
                                                     
                    //Leo el mensaje que me envia para ver si quiere realizar otra operacion
                    peticion = in.readUTF();	
                }
                                                 
                 	
            	//Cierro el socket
                sc.close();
                System.out.println("\n>>>> Cliente desconectado ...");
           
            
            }
                   


        } catch (IOException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
